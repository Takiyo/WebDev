<?php
if (isset($_COOKIE['gwAdminLoggedIn'])){
  if ($_COOKIE['gwAdminLoggedIn'] == 'true')
  {
    $adminLoggedIn = true;
  }
}
?>