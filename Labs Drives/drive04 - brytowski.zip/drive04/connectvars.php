<?php
//Softdev
// define('DB_HOST', 'softdev.mstclab.com');
// define('DB_USER', 'tbrytowski');
// define('DB_PASSWORD', 'password');
// define('DB_NAME', 'tbrytowski');

//Local
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASSWORD', '');
define('DB_NAME', 'tbrytowski');

