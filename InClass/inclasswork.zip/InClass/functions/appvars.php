<?php
//Application variables