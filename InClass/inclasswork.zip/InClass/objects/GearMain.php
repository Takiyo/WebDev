<!--

Everything below the createPage function is part of the function.
    This is so you can modularly create the same page on another file
    but link different style sheets/scripts/etc

    TODO - 
        PDO
        Delete topPlayersUse
-->


<?php
$page = new GearMain();
$page->createPage();
class GearMain{
    public function __construct(){

    }

    public function createPage(){
        ?>
        <div class="row" style="height:100%">
            <div class="col-sm-4">               
            </div>
            <?php
            
            if (isset($_POST['submit'])) {
            $playerName = $_POST['playerName'];
            $characterName = $_POST['characterName'];
            $datePlayerStarted = $_POST['datePlayerStarted'];
            $coolnessRating = $_POST['coolnessRating'];
            $image = $_FILES['gamerMug']['name'];
            $output_form = 'no';

            if (empty($playerName) || empty($characterName) || empty($datePlayerStarted)
                || empty($coolnessRating))
            {
                //TODO make similar to inclass example - 100% width red div
                echo '<h2 style="color:red; border:1px dotted black; width:35%;">Please fill out the entire form.</h2></br>';
                $output_form='yes';
            }
        }
        else
        {
            $output_form='yes';
        }

        if (!empty($playerName) || !empty($characterName) || !empty($datePlayerStarted) || !empty($coolnessRating)) {
            error_reporting(0);
            ini_set('display_errors', 0);
          
              // set connectvars
              $host = DB_HOST;
              $db = DB_NAME;
              $user = DB_USER;
              $pass = DB_PASSWORD;
              $charset = 'utf8mb4';
              $dsn = "mysql:host=$host;dbname=$db;charset=$charset";
              $options = [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
              ];
            
              // Establish connection
              try {
                $pdo = new PDO($dsn, $user, $pass, $options);
              } catch (\PDOException $e) {
                throw new \PDOException($e->getMessage(), (int)$e->getCode());
              }


            $stmt = $pdo->prepare("INSERT INTO dbfzcharacter (playerName, characterName, datePlayerStarted, coolnessRating) "
                . "VALUES ('$playerName', '$characterName', '$datePlayerStarted', '$coolnessRating')");
            $stmt->execute();

            if ($output_form == 'no') {
                echo "Your inexperienced opinion has been duly noted.</br>Here's what you entered:</br></br>" .
                    "Player name: " . $playerName . "</br>" .
                    "Character name: " . $characterName . "</br>" .
                    "Date you started: " . $datePlayerStarted . "</br>" .
                    "Coolness Rating: " . $coolnessRating . "</br></br>";

                // Attempting to upload file.
                uploadImage();
                echo "<img src='" . "uploads/" . "$image" . "'/>";
            }
        }

    if ($output_form == 'yes') {
        ?>
        <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post" enctype="multipart/form-data">

            <legend>What's your name?</legend>
            <input type="text" id="playerName" name="playerName" onblur="requiredField(this)" required/><br/><br/>

            <legend>What character are you giving your opinion on?</legend>
            <input type="text" id="characterName" name="characterName" onblur="requiredField(this)" required /><br/><br/>

            <legend>What date did you start playing DBFZ?</legend>
            <input type="date" id="datePlayerStarted" name="datePlayerStarted"/><br/><br/>

            <legend>How cool is this character to you from 1-100?</legend>
            <input type="range" name="coolnessRating" id="coolnessRating" value="50" min="1" max="100"
                oninput="coolnessRatingOutput.value = coolnessRating.value">
            <output name="coolnessRatingOutput" id="coolnessRatingOutput">50</output><br><br>

            <label for="gamerMug">Give us a face to go with the bad opinion.</label><br>
            <input type="file" id="gamerMug" name="gamerMug"/>
            <input type="hidden" name="MAX_FILE_SIZE" value="32768" />
            </br></br>

            <input type="submit" value="Submit Survey" name="submit"/>
        </form>
        <div class="col-sm-4">               
        </div>

    </div>

    <?php
}
?>


        <?php


    }
}
