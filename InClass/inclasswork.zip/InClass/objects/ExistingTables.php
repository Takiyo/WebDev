<!--

Everything below the createPage function is part of the function.
    This is so you can modularly create the same page on another file
    but link different style sheets/scripts/etc

    TODO - 
        PDO
        Delete topPlayersUse
-->


<?php
$page = new ExistingTables();
$page->createPage();
class ExistingTables{
    public function __construct(){

    }

    public function createPage(){
        ?>

    <h2>DBFZ Existing Tables</h2>


    <form action='<?php echo $_SERVER['PHP_SELF']; ?>' method="post">
        <?php

        error_reporting(0);
        ini_set('display_errors', 0);

        // set connectvars
        $host = DB_HOST;
        $db = DB_NAME;
        $user = DB_USER;
        $pass = DB_PASSWORD;
        $charset = 'utf8mb4';
        $dsn = "mysql:host=$host;dbname=$db;charset=$charset";
        $options = [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ];

        // Establish connection
        try {
            $pdo = new PDO($dsn, $user, $pass, $options);
        } catch (\PDOException $e) {
            throw new \PDOException($e->getMessage(), (int)$e->getCode());
        }

        if (isset($_POST['displayBTN']) && isset($_POST['checked_values'])) {
            echo '<table style="width:100%" border="1px solid;">
            <tr>
                <th>playerId</th>
                <th>playerName</th>
                <th>characterName</th>
                <th>datePlayerStarted</th>
                <th>coolnessRating</th>      
            </tr>';

            // Displays Selected Values
            foreach ($_POST['checked_values'] as $checked_id)
            {

                $stmt = $pdo->prepare("SELECT playerId, playerName, characterName, datePlayerStarted, coolnessRating
            FROM dbfzcharacter WHERE playerId = $checked_id");

                $stmt->execute();

               foreach ($stmt as $row){
                echo '<tr><td>' . $row['playerId'] . '</td><td>'
                . $row['playerName'] . '</td><td>'
                . $row['characterName'] . '</td><td>'
                . $row['datePlayerStarted'] . '</td><td>'
                . $row['coolnessRating'] . '</td></tr>';
                }
                echo '</table>';
            }
        }

            // Deletes Selected Values
        foreach ($_POST['checked_values'] as $checked_id) {

            if (isset($_POST['deleteBTN']) && isset($_POST['checked_values'])) {
                $stmt = $pdo->prepare("DELETE FROM dbfzcharacter WHERE playerId = $checked_id");
                $stmt->execute();
                echo '<h4 class="error">Record ' . $checked_id . ' deleted.</h4>';
            }
        }

        $stmt = $pdo->prepare('SELECT playerId FROM dbfzcharacter');
        $stmt->execute();

            foreach ($stmt as $row)
            {
                echo '<input type="checkbox" value="' . $row['playerId']
                    . '" name="checked_values[]">' . $row['playerId'] . "</input><br>";
            }
            ?>

        <input name="displayBTN" type="submit" value="Display">
        <input name="deleteBTN" type="submit" value="Delete">
    </form>
            <?php
        }
}