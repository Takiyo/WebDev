

<div class="row align-items-center h-100 m-3"> <!-- start 3 col layout -->
    <div class="col-sm"></div>
    <div class="col-sm card card-block mx-auto h-75 myCard">
        <div class="mx-auto my-3 text-center">
        <h3>The product was successfully submitted!</h3>

        <p><?php echo anchor('forms/create', 'Try it again!'); ?></p>

        </div> <!-- centered div -->
        <!-- TODO -->
    </div> <!-- col -->
    <div class="col-sm"></div>
    
</div> <!-- row -->
    
