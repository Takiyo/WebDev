<?php
echo '<h2>'.$product_item['title'].'</h2>';
echo $product_item['text'];
echo 'view';