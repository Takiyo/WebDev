<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Risky Jobs</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- CSS -->
    <link href="<?php echo URL; ?>css/style.css" rel="stylesheet">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

</head>
<body>
    <!-- logo -->
    <div class="logo">
        <a href="<?php echo URL; ?>" style="text-decoration:none; color:inherit; margin-left:20%; margin-right: 20%;">Risky Jobs</a>
    </div>

    <!-- navigation -->
    <div class="navigation">

        <a href="<?php echo URL; ?>">home</a>
        <a href="<?php echo URL;?>jobs/index">Registered Applicants</a>
    </div><br>
<hr>
