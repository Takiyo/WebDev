<!DOCTYPE html>
<html>
<title>W3.CSS Template</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Inconsolata">
<link rel="stylesheet" href="css/style.css">
<script type="text/javascript" src="js/displayfunctions.js"></script>
<script type="text/javascript" defer src="js/validation.js"></script>
<style>
    body, html {
        height: 70%;
        font-family: "Inconsolata", sans-serif;
    }
    .bgimg {
        background-position: center;
        background-size: cover;
        background-image: url("images/bg.jpg");
        min-height: 75%;
    }
    .menu {
        display: none;
    }
</style>
</head>


<body>
<div class="w3-top">
    <div class="w3-row w3-padding w3-black">
        <div class="w3-col s4">
            <a href="index.php" class="w3-button w3-block w3-black">HOME</a>
        </div>
        <div class="w3-col s4">
            <a href="signup.php" class="w3-button w3-block w3-black">SIGN UP</a>
        </div>
        <div class="w3-col s4">
            <a href="login.php" class="w3-button w3-block w3-black">LOG IN</a>
        </div>
    </div>
</div>


<!-- Header with image -->
<header class="bgimg w3-display-container w3-grayscale-min" id="home">
    <div class="w3-display-bottomleft w3-center w3-padding-large w3-hide-small">
        <span class="w3-tag">LOGIN STATUS PLACEHOLDER</span>
    </div>
    <div class="w3-display-middle w3-center">
        <span id="titleheader" class="w3-text-white" style="font-size:90px">Health<br>Watch</span>
    </div>
    <div class="w3-display-bottomright w3-center w3-padding-large">
        <span class="w3-text-white">LOGIN STATUS PLACEHOLDER</span>
    </div>
</header>
<div class="w3-content" style="max-width:700px">


<?php
require_once('connectvars.php');
require_once('appvars.php');

// Start the session
session_start();

// Clear the error message
$error_msg = "";

// If the user isn't logged in, try to log them in
if (!isset($_SESSION['id'])) {
    if (isset($_POST['submit'])) {
        // Connect to the database
        $dbc = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);

        // Grab the user-entered log-in data
        $user_username = $_POST['username'];
        $user_password = $_POST['password'];

        if (!empty($user_username) && !empty($user_password)) {

            // Look up the username and password in the database
            $query = "SELECT id, username FROM exercise_user WHERE username = '$user_username' AND password = SHA('$user_password')";
            $data = mysqli_query($dbc, $query)
                or die("Error with query.");

           // echo mysqli_num_rows($data);
            //echo $user_username . ' ' . $user_password;

            if (mysqli_num_rows($data) == 1) {
                // The log-in is OK so set the user ID and username session vars (and cookies), and redirect to the home page
                $row = mysqli_fetch_array($data);
                $_SESSION['id'] = $row['id'];
                $_SESSION['username'] = $row['username'];
                setcookie('id', $row['id'], time() + (60 * 60 * 24 * 30));    // expires in 30 days
                setcookie('username', $row['username'], time() + (60 * 60 * 24 * 30));  // expires in 30 days
                $home_url = 'http://' . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']) . '/index.php';
                header('Location: ' . $home_url);
            }
            else {
                // The username/password are incorrect so set an error message
                $error_msg = 'Sorry, your username and/or password did not match any in our database.';

            }
        }
        else {
            // The username/password weren't entered so set an error message
            $error_msg = 'Sorry, you must enter your username and password to log in.';

        }
    }
}
?>



            <?php
            echo '<div class="col-sm-6 offset-sm-3 center">';

            // If the session var is empty, show any error message and the log-in form; ELSE confirm the log-in
            if (empty($_SESSION['id'])) {
                echo '<p class="error">' . $error_msg . '</p>';
                ?>

                <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
                    <fieldset>
                        <legend>Log In</legend>
                        <label for="username">Username:</label>
                        <input id="username" class="w3-input w3-padding-8 w3-border" type="text" name="username" value="<?php if (!empty($user_username)) echo $user_username; ?>" /><br />
                        <label for="password">Password:</label>
                        <input class="w3-input w3-padding-8 w3-border" type="password" name="password" />

                    </fieldset><br>
                    <input type="submit" value="Log In" name="submit" />
                </form>

                <?php
            }
            else {
                echo('<p class="login">You are logged in as ' . $_SESSION['username'] . '.</p>');
                echo "<p> Is this not you? If not, please <a href='logout.php'>log out</a>.";
            }
            ?>
        </div>
</body>
</html>
