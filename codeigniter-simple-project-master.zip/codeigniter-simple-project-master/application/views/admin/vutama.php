

      
	  <?php echo $_header; ?>

	  <?php echo $_menu; ?>

	  <?php echo $_content; ?>

	  <?php echo $_footer; ?>





