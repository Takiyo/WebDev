    </div>  
    
    <footer>
        <hr>
        <p class="pull-right">Aplikasi Pendaftaran Anggota Cantha Pratala</p>
        <p>By <a href="#">Mahasiswa STMIK Bumigora Mataram</a></p>
    </footer>

  </body>
</html>