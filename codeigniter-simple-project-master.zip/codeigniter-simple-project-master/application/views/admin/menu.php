    <div class="container-fluid">
        
        <div class="row-fluid">
            <div class="span3">
                <div class="sidebar-nav">
                  <div class="nav-header" data-toggle="collapse" data-target="#dashboard-menu"><i class="icon-user"></i>Menu Utama</div>
                    <ul id="dashboard-menu" class="nav nav-list collapse in">
                        <li><a href="<?php echo base_url();?>index.php/chome/databarang">Data Barang</a></li>
                        <li ><a href="<?php echo base_url();?>index.php/chome/datapenjualan">Data Penjualan</a></li>
                        <li ><a href="<?php echo base_url();?>index.php/chome/dataadmin">Data Admin</a></li>
                        <li ><a href="<?php echo base_url();?>index.php/chome/laporanpenjualan">Laporan Penjualan</a></li>
                    </ul>
            </div>
        </div>