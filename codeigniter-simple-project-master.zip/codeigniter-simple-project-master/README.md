# codeigniter-simple-project

Simple Project Using Codeigniter Framework

Some Features in this simple project:

1. Using Codeiniter version 3.1.5

2. Using 3 tables in the database table

3. There is an Insert process, Update Delete

4. Integrated FPDF & can print reports into PDF

5. Using the DataTable Plugin

6. There is a Login and Logout process.

7. Templating

User = admin </br>
Pass = admin
