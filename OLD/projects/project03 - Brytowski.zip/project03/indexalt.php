<!DOCTYPE html>
<html>
<title>Mad Libs</title>
<br>
<a href="index.php">Give me my css back!</a>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<?php
include('objects/MadLibs.php');
?>



</html>
