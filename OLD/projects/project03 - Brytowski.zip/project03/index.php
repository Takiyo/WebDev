<!DOCTYPE html>
<html>
<title>Mad Libs</title>
<br>
<a href="indexalt.php">Get rid of this nasty CSS!</a>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway">
<style>
    body, h1, h2, h3, h4, h5 {
        font-family: "Raleway", sans-serif
    }
</style>
<?php
    include('objects/MadLibs.php');
?>
</html>
