<?php
// Define database connection constants
define('WALK_MODIFIER', 1);
define('RUN_MODIFIER', 1.5);
define('WEIGHTLIFT_MODIFIER', 1.6);
define('SWIM_MODIFIER', 2.1);

