<?php
$foot = new footer();
$foot->createPage();

class footer{
    public function __construct()
    {

    }

    public function createPage()
    {
        ?>

<!-- Footer -->
<footer class="w3-center w3-light-grey w3-padding-48 w3-large">
    <p></p>
</footer>
<?php
    }
}