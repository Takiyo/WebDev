<div class="row">
    <div class="col-sm">
    </div>
    <div class="col-sm">
        <?php

echo '<h2>'.$news_item['title'].'</h2>';
echo $news_item['text'];

?>
    </div>
    <div class="col-sm">
        
    </div>

</div>

