<div class="row">
    <div class="col-sm"></div>
    <div class="col-sm">
        <div class="card text-white bg-success mb-3" style="max-width: 18rem;">
        <div class="card-body">
            <h5 class="card-title">Submission Successful!</h5>
        </div>
    </div>
    </div>
    <div class="col-sm"></div>
</div>
