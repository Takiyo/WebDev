<?php
require_once('pagecomponents/header.php');
require_once('pagecomponents/main.php');
//require_once('pagecomponents/footer.php');

?>
<!--



    
    Project is client-deliverable although a bit spartan.  

validation of fields needs to be next to the field itself.

validation does not preclude special characters or numbers.  Need to list madlbs from newest to oldest.

﻿folder structure should include the following:  css, js, images, etc..  Javascript validation function exists,but is not used. 

missing sql for project for me to recreate db.

madlibs should be in the opposite order as you have them.  

index does a ton of the heavy lifting here.  You have a nice object-oriented structure in places.



-->
