            <div class="w3-card w3-margin" style="float:right; width=20%;">
                <div class="w3-container w3-padding">
                    <h4>Need Word Suggestions? Try:</h4>
                </div>
                <div class="w3-container w3-white">
                    <p>
                        <span class="w3-tag w3-black w3-margin-bottom">neat</span> <span
                                class="w3-tag w3-light-grey w3-small w3-margin-bottom">huge</span>
                        <span class="w3-tag w3-black w3-margin-bottom">undulate</span> <span
                                class="w3-tag w3-light-grey w3-small w3-margin-bottom">gravitate</span>
                        <span class="w3-tag w3-black w3-margin-bottom">otter</span> <span
                                class="w3-tag w3-light-grey w3-small w3-margin-bottom">boy</span>
                        <span class="w3-tag w3-black w3-margin-bottom">purplish-black</span> <span
                                class="w3-tag w3-light-grey w3-small w3-margin-bottom">electrifying</span>
                        <span class="w3-tag w3-black w3-margin-bottom">bottle</span> <span
                                class="w3-tag w3-light-grey w3-small w3-margin-bottom">grotesque</span>
                        <span class="w3-tag w3-black w3-margin-bottom">cry</span> <span
                                class="w3-tag w3-light-grey w3-small w3-margin-bottom">tipsy</span>
                        <span class="w3-tag w3-black w3-margin-bottom">gone</span> <span
                                class="w3-tag w3-light-grey w3-small w3-margin-bottom">hot minute</span>

                    </p>
                </div>
            </div>