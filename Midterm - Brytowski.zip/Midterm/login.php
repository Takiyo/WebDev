<?php
  include('objects/GearHeader.php');
  include('objects/Logged.php');
  include('objects/GearFooter.php');
?>