<?php
  include('objects/GearHeader.php');
  include('objects/Unlogged.php');
  include('objects/GearFooter.php');
?>