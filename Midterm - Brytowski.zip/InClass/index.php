<?php
  include('objects/GearHeader.php');
  include('objects/GearMain.php');
  include('objects/GearFooter.php');
?>