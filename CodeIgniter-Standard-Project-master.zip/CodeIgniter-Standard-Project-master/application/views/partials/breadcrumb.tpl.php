<?php if ($this->breadcrumbs->generate_breadcrumb()):?>
	<?php echo $this->breadcrumbs->generate_breadcrumb();?>
<?php endif;?>